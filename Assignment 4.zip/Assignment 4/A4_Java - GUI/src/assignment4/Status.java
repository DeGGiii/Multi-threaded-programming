package assignment4;

public enum Status
{
    EMPTY,
    CHECKED,
    NEW
}
